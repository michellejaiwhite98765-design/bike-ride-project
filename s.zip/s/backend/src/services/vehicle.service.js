import { vehicleRepository } from "../repositories/vehicle.repository.js";
import { ApiError } from "../utils/ApiError.js";
import { audit } from "../utils/audit.js";
import { cloudinaryService } from "./cloudinary.service.js";
import { way2ApiService } from "./way2api.service.js";

async function assertOwner(vehicleId, userId) {
  const vehicle = await vehicleRepository.findById(vehicleId);
  if (!vehicle) throw ApiError.notFound("Vehicle not found");
  if (vehicle.ownerId !== userId) throw ApiError.forbidden("You do not own this vehicle");
  return vehicle;
}

export const vehicleService = {
  async create(userId, data) {
    const vehicle = await vehicleRepository.create(userId, data);
    await audit(null, { userId, action: "VEHICLE_CREATED", entityType: "Vehicle", entityId: vehicle.id });
    return vehicle;
  },

  listMine(userId) {
    return vehicleRepository.findByOwner(userId);
  },

  async getById(userId, vehicleId) {
    return assertOwner(vehicleId, userId);
  },

  async update(userId, vehicleId, data) {
    const existing = await assertOwner(vehicleId, userId);
    // Owners cannot directly set verification status.
    delete data.verificationStatus;

    const verificationRelevantFields = ["registrationNumber", "brand", "model", "manufacturingYear"];
    const changedVerificationInput = verificationRelevantFields.some(
      (field) => data[field] !== undefined && String(data[field]) !== String(existing[field])
    );

    if (changedVerificationInput) {
      data.verificationStatus = "PENDING";
      data.verificationProvider = null;
      data.verificationOrderId = null;
      data.verificationData = null;
      data.verificationCheckedAt = null;
      data.verificationFailureReason = null;
      data.verifiedAt = null;
    }
    const vehicle = await vehicleRepository.update(vehicleId, data);
    await audit(null, { userId, action: "VEHICLE_UPDATED", entityType: "Vehicle", entityId: vehicleId });
    return vehicle;
  },

  async uploadRcDocument(userId, vehicleId, file) {
    await assertOwner(vehicleId, userId);

    const uploaded = await cloudinaryService.uploadRcDocument(file, vehicleId);
    const vehicle = await vehicleRepository.update(vehicleId, {
      rcDocumentUrl: uploaded.secureUrl,
      rcDocumentPublicId: uploaded.publicId,
      verificationStatus: "PENDING",
      verificationFailureReason: null,
      updatedAt: new Date(),
    });

    await audit(null, { userId, action: "VEHICLE_RC_DOCUMENT_UPLOADED", entityType: "Vehicle", entityId: vehicleId });
    return vehicle;
  },

  async verify(userId, vehicleId) {
    const vehicle = await assertOwner(vehicleId, userId);

    if (vehicle.verificationStatus === "VERIFIED" && vehicle.verificationData) {
      return { vehicle, cached: true, providerResult: vehicle.verificationData };
    }

    const existingRegistration = await vehicleRepository.findByRegistrationNumber(vehicle.registrationNumber);
    if (existingRegistration && existingRegistration.id !== vehicleId && existingRegistration.verificationStatus === "VERIFIED") {
      throw ApiError.conflict("This registration number is already attached to another verified vehicle");
    }

    try {
      const verification = await way2ApiService.verifyRc({ registrationNumber: vehicle.registrationNumber });
      const result = verification.result;
      const updated = await vehicleRepository.update(vehicleId, {
        verificationStatus: "VERIFIED",
        verificationProvider: "WAY2API",
        verificationOrderId: verification.orderId,
        verificationData: result,
        verificationCheckedAt: new Date(),
        verificationFailureReason: null,
        verifiedAt: new Date(),
      });

      await audit(null, { userId, action: "VEHICLE_VERIFIED", entityType: "Vehicle", entityId: vehicleId });
      return { vehicle: updated, cached: false, providerResult: result };
    } catch (error) {
      const providerPayload = error.way2Api || null;
      const updated = await vehicleRepository.update(vehicleId, {
        verificationStatus: "REJECTED",
        verificationProvider: "WAY2API",
        verificationOrderId: providerPayload?.order_id || null,
        verificationData: providerPayload?.data?.result || null,
        verificationCheckedAt: new Date(),
        verificationFailureReason: error.message,
        verifiedAt: null,
      });

      await audit(null, { userId, action: "VEHICLE_VERIFICATION_FAILED", entityType: "Vehicle", entityId: vehicleId });
      return { vehicle: updated, cached: false, providerResult: providerPayload?.data?.result || null, rejected: true };
    }
  },

  async remove(userId, vehicleId) {
    await assertOwner(vehicleId, userId);
    const activeRideCount = await vehicleRepository.countActiveRides(vehicleId);
    if (activeRideCount > 0) {
      throw ApiError.conflict("Cannot delete a vehicle with active or upcoming rides");
    }
    await vehicleRepository.update(vehicleId, { isActive: false });
    await audit(null, { userId, action: "VEHICLE_DELETED", entityType: "Vehicle", entityId: vehicleId });
  },
};
